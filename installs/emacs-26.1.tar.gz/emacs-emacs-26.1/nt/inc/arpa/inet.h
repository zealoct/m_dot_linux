/* null version of <arpa/inet.h> - <sys/socket.h> has everything */

